//
//  StatsView.swift
//  flareup
//
//  Created by Abril Aguilar-Lopez on 5/29/25.
//
import SwiftUI

struct StatsView: View {
    var body: some View {
        Text("Stats Screen")
            .font(.largeTitle)
            .padding()
    }
}
