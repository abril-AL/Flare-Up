//
//  flareupTests.swift
//  flareupTests
//
//  Created by Richelle Shim on 5/9/25.
//

import Testing
@testable import flareup

struct flareupTests {

    }


